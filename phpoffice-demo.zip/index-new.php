<?php
	require_once __DIR__.DIRECTORY_SEPARATOR.'vendor'.DIRECTORY_SEPARATOR.'autoload.php';
	use \PhpOffice\PhpWord\PhpWord;
	use \PhpOffice\PhpWord\TemplateProcessor;
	require_once __DIR__.DIRECTORY_SEPARATOR.'ExtTemplateProcessor.php';
	use DocxMerge\DocxMerge;
	$base_doc_dir = __DIR__.DIRECTORY_SEPARATOR.'docs'.DIRECTORY_SEPARATOR;
	$base_doc_output_dir = __DIR__.DIRECTORY_SEPARATOR.'updated'.DIRECTORY_SEPARATOR;
	@chmod($base_doc_output_dir, 0777);
	$base_tmp_dir =  __DIR__.DIRECTORY_SEPARATOR.'tmp'.DIRECTORY_SEPARATOR;
	$documentUpdateName = '';
	$documentDownloadUrl = '';

	\PhpOffice\PhpWord\Settings::setTempDir($base_tmp_dir);

	if(!empty($_POST['document_upload'])) {
		$xml = simplexml_load_file("50828MDF-HQ.xml") or die("Error: Cannot create object");

		$xml_arr = (array)$xml;

		if (PHP_SAPI == 'cli') {
			die('This example should only be run from a Web Browser');
		}

		$file_paths = explode(",", $_POST['selected_dir']);
		$files = array();
		foreach ($file_paths as $f_key => $file_path) {

			$document_info = pathinfo($base_doc_dir.$file_path);
			$documentName = $document_info['filename'];
				
			$phpWord = new PhpWord();
			$documentUpdateName = $base_doc_output_dir.$documentName.'-updated'.'.'.$document_info['extension'];
			$documentDownloadUrl = DIRECTORY_SEPARATOR.'tmp'.DIRECTORY_SEPARATOR."merge-result.docx";

			$files[$f_key] = $documentUpdateName;

			$document = new ExtTemplateProcessor($base_doc_dir.$file_path);
			$templateVariables = $document->getVariables();

			$search_keys = []; 
			$search_val = [];
			foreach ($templateVariables as $key) {
				if(!empty($xml_arr[$key])){
					if(!is_array($xml_arr[$key])) {
						$value = $xml_arr[$key];
						$search_replace[$key] = htmlentities($value);
						if($value == strip_tags($value)) {
							$search_keys[] = $key;
							$search_val[] = htmlentities($value);
						} else {
							$search_keys[] = $key;
							// $section = $phpWord->addSection();
							$html = html_entity_decode($value);
							$search_val[] = htmlentities(strip_tags($html));
						}
					} else {
						$search_keys[] = $key;
						$search_val[] = '';
					}
				} else {
					$search_keys[] = $key;
					$search_val[] = '';
				}
			}

			@unlink($documentUpdateName);
			
			$document->setValue($search_keys, $search_val);
			ob_clean();	
			$document->saveAs($documentUpdateName);
		}

		if (count($file_paths) > 1) {		
			$result_path = $base_tmp_dir."merge-result.docx";
			if(file_exists($result_path))
			{
				@chmod($result_path,0755);
			}
			$docxMerge = \Jupitern\Docx\DocxMerge::instance()
						->addFiles($files)
						->save($base_tmp_dir."merge-result.docx", true);

			header('Content-Type: application/docx');
			header('Content-Disposition: attachment; filename=merge-result.docx');
			header('Pragma: no-cache');
			readfile($base_tmp_dir."merge-result.docx");
			exit;			
		} else {
			$result_path = $base_tmp_dir."merge-result.docx";
			if(file_exists($result_path))
			{
				@chmod($result_path,0755);
			}
			$docxMerge = \Jupitern\Docx\DocxMerge::instance()
						->addFiles($files)
						->save($base_tmp_dir."merge-result.docx", true);

			header('Content-Type: application/docx');
			header('Content-Disposition: attachment; filename=merge-result.docx');
			header('Pragma: no-cache');
			readfile($base_tmp_dir."merge-result.docx");
			exit;
		}
	}

	function getDirContents($dir, &$results = array()){
		$files = scandir($dir);

		foreach($files as $key => $value){
		    $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
		    if(!is_dir($path)) {
		        $results[] = $value;
		    } else if($value != "." && $value != "..") {
		        getDirContents($path, $results);
		        $results[] = $value;
		    }
		}

		return $results;
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Dynamic Word Docs</title>
		<script type="text/javascript" src="bower_components/jquery/dist/jquery.min.js"></script>
		<script type="text/javascript" src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="bower_components/jstree/dist/jstree.min.js"></script>
		<script type="text/javascript" src="bower_components/sweetalert/sweetalert2.min.js"></script>
		<link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="bower_components/jstree/dist/themes/default/style.min.css">
		<link rel="stylesheet" type="text/css" href="bower_components/sweetalert/sweetalert2.min.css">

		<style type="text/css">
			html {
				height: 100%;
			}
			body {
				font-family: Arial,sans-serif;
				font-size: 14px;
				margin: 0;
				padding: 0;
				height: 100%;
				min-height: 100%;
			}
			h1 {
				font-size: 1.6em;
			}
			h2 {
				font-size: 1.5em;
			}
			.col-container {
				display: table;
				width: 100%;
				height: 100%;
				table-layout: fixed;
			}
			.col {
				display: table-cell;
				vertical-align: middle;
			}
			.col.left {
				width: 30%;
				background: #f5f5f5;
	    		border-right: 1px solid #ccc;
			}
			.col.right {
				width: 70%;
				overflow: hidden;
			}
			.left-container {
				padding: 0 15px;
			}
			#jstree {
				overflow-y: hidden;
				overflow-x: auto;
				width: 100%;
				margin-bottom: 15px;
			}
			.left-container fieldset{
				padding: 15px;
			}
			.left-container fieldset,
			.left-container legend {
				border: 1px solid rgba(0, 0, 0, 0.5);
			}
			.left-container legend {
				padding: 3px 5px;
				margin: 0;
				font-size: 1em;
				display: inline-block;
				width: auto;
			}
			.left-container fieldset + fieldset {
				margin-top: 15px;
			}
			.btn {
				display: block;
				margin: 10px 0;
				padding: 20px 10px;
				color: rgba(255, 255, 255, 0.8);
				text-decoration: none;
				border-radius: 3px;
				border: none;
				font-size: 1.5em;
				font-weight: bold;
				text-align: center;
				box-sizing: border-box;
			}
			.error {
				font-size: 1em;
				background: #e20b0b;
				padding: 10px;
				color: rgba(255, 255, 255, 0.8);
			}
			.frame {
				box-sizing: border-box;
				border: none;
			}
			.doc-helper {
				text-align: center;
				text-align: center;
				background: #79d6e0;
				width: 100%;
				height: 100%;
				display: table;
			}
			.helper-container {
				display: table-cell;
				vertical-align: middle;
			}
			.doc-helper img {
				max-width: 200px;
	    		margin: auto;
			}
			.info-text {
				font-size: 2em;
				font-weight: bold;
				color: rgba(0, 0, 0, 0.8);
			}

		</style>
	</head>
	<body>
		<div class="col-container">
			<div class="col left">
				<div class="left-container">
					<h1>Select files to process.</h1>

					<h2>Please select a file to which you want to process your doc.</h2>
					<?php 
						if (!empty($errors)){
							foreach ($errors as $error) {
								echo '<p class="error">'.$error.'</p>';
							}

							foreach ($success as $s_msg) {
								echo '<p class="success">'.$s_msg.'</p>';
							}
						}
					?>
					
					<div id="jstree">
						
					</div>
					<form action="" method="post" onsubmit="validateSelections();" enctype="multipart/form-data">
						<input type="hidden" name="selected_dir" id="path" value="">
						<button type="submit" class="btn btn-primary btn-lg btn-block disabled" id="send_to_word" name="document_upload" value="Upload">Send to word</button>
					</form>

<!-- 					<?php 
						if(!empty($documentUpdateName)){
							if(file_exists($documentUpdateName)){
								?>
								<a class="btn btn-primary btn-lg btn-block" href="<?php echo "/phpoffice-demo".$documentDownloadUrl; ?>">Send to word</a>
								<?php	
							}
						}
					?>	 -->
				</div>
			</div>
		</div>
			
		<script type="text/javascript">
			var arr = [];
			var arr_files = [];
			var arr_folders = [];
			$(document).ready(function(){
			
				var node_arr = [];
				function sortNumber(a,b) {
				    return b - a;
				}

				var node_arr = [];
				function getParentArr(s_node){
					if(s_node){
						if(s_node.parent != "#"){
							var curr_node = $('#jstree').jstree(true).get_node(s_node.parent);
							node_arr.push(curr_node.id.split("_")[1]);
							getParentArr(curr_node);
						}
						node_arr.sort(sortNumber);
						return node_arr.reverse();
					} else {
						return node_arr;
					}
				}

				var i, j, r = [], n, m;
				function selectEvent(data){
					arr_folders = [];
					var directory_separator = '\<?php echo DIRECTORY_SEPARATOR ?>';
					i, j, r = [], n, m;
					for(i = 0, j = data.selected.length; i < j; i++) {
						r.push(data.instance.get_path(data.selected[i]));
					}

					var directory_separator = '\<?php echo DIRECTORY_SEPARATOR ?>';
					var folder = [];
					var file = [];
					node_arr = [];
					var parents = getParentArr(data.node);
					node_arr = [];
					if(parents.length >= 1){
						for (var i = 0; i < parents.length; i++) {
							if(parents[i] != '#'){
								if($('#j1_'+parents[i]).children('a').text().replace(/ /g, "-").split('.')[1]){
									file.push($('#j1_'+parents[i]).children('a').text());
								} else {
									folder.push($('#j1_'+parents[i]).children('a').text());
								}
							}
						}
						if(data.node.text.replace(/ /g, "-").split('.')[1] == 'docx'){
							file.push(data.node.text);
						} else {
							if($.inArray(data.node.text, folder) === -1){
								folder.push(data.node.text);
							}
						}
					} else {
						if(data.node.text.replace(/ /g, "-").split('.')[1] == 'docx'){
							file.push(data.node.text);
						} else {
							folder = [];
							if($.inArray(data.node.text, folder) === -1){
								folder.push(data.node.text);
							}
						}
					}

					arr_folders.push(folder.join(directory_separator));

					arr_folders.push(file);
					arr_folders = arr_folders.filter(function(v){return v!==''});
					console.log(arr_folders.join(directory_separator));
					if(arr_folders.join(directory_separator).split('.')[1] == 'docx'){
						if($.inArray(arr_folders.join(directory_separator), arr_files) === -1){
							arr_files.push(arr_folders.join(directory_separator));
						}
					}
					arr_files = arr_files.filter(function(v){return v!==''});
					arr_files = [];

					if (r.length > 0) {
						for (var i = 0; r.length > i; i++) {
							if(r[i].join(directory_separator).split('.')[1] == 'docx'){
								arr_files.push(r[i].join(directory_separator).replace(/ /g, "-"));
							};
						}
					}
					console.log(arr_files);
					$('#path').val(arr_files.join(","));
				}

				arr_files = [];
				$('#jstree').jstree({
					'core' : {
						"check_callback" : true,
						'data' : {
							'url' : function (node) {
								var directory_separator = '\<?php echo DIRECTORY_SEPARATOR ?>';
								var folder = [];
								if(node.id != "#"){
									node_arr = [];
									var parents_n = getParentArr(node);
									if(parents_n.length >= 1){
										for (var i = 0; i < parents_n.length; i++) {
											if(parents_n[i] != '#'){
												if($('#j1_'+parents_n[i].toString()).children('a').text().replace(/ /g, "-").split('.')[1] != 'docx'){
													folder.push($('#j1_'+parents_n[i].toString()).children('a').text());
												} 
											}
										}
										if(node.text.replace(/ /g, "-").split('.')[1] != 'docx'){
											folder.push(node.text);
										}
									} else {
										if(node.text.replace(/ /g, "-").split('.')[1] != 'docx'){
											folder.push(node.text);
										}
									}
								}
								return node.id === '#' ?
								'ajax_tree_root.php' :
								'ajax_tree_children.php?folder='+folder.join(directory_separator);
							},
							dataType: 'JSON',
							'data' : function (node) {
								return { 'id' : node.id };
							},
							timeout: 2000,
							'progressive_render': true,
		            		'progressive_unload': false,
		            		'cache': false,
						},
					},
					"plugins" : [ "checkbox" ]	
				});


				$('#jstree')
					.on('select_node.jstree', function(e, data){
		                $('#jstree').jstree(true).open_node(data.node,function(o_data){
		                	$('#jstree').on('after_open.jstree', function (e, a_data) {
		                		var selected = $('#jstree').jstree(true).get_selected();
		                		data.selected = selected;
		                		selectEvent(data);
		                		toggleButton();
		                	});
		                });
					});


				function toggleButton(){
					if(arr_files.length > 0){
							$("#send_to_word").removeClass("disabled");
						} else {
							$("#send_to_word").addClass("disabled");
						}
				}


				function changedJstree(){
					$('#jstree')
						.on('changed.jstree', function (e, data) {
							if(data.node){
								selectEvent(data);
							}
							toggleButton();
						});
				}
				changedJstree();
			});

			function validateSelections(){
				if(arr_files.length == 0){
					swal('Please select a document first.!');
					event.preventDefault();
					return false;
				}
			};
		</script>
	</body>
</html>
